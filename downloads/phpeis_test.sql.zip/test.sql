-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 10, 2011 at 01:48 PM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `phpeis`
--

-- --------------------------------------------------------

--
-- Table structure for table `bans`
--

CREATE TABLE IF NOT EXISTS `bans` (
  `ban_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(60) NOT NULL,
  `ipaddr` varchar(100) NOT NULL,
  `expires` int(11) NOT NULL,
  `ban_maker` int(11) NOT NULL,
  PRIMARY KEY (`ban_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `bans`
--


-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(100) NOT NULL,
  `cat_desc` varchar(100) DEFAULT NULL,
  `disp_pos` int(11) DEFAULT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `categories`
--


-- --------------------------------------------------------

--
-- Table structure for table `censor`
--

CREATE TABLE IF NOT EXISTS `censor` (
  `censor_id` int(11) NOT NULL AUTO_INCREMENT,
  `searchword` varchar(100) NOT NULL,
  `replaceword` varchar(100) NOT NULL,
  PRIMARY KEY (`censor_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `censor`
--


-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE IF NOT EXISTS `comment` (
  `cmt_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `email` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `ip` varchar(50) DEFAULT NULL,
  `tut_id` int(11) NOT NULL,
  PRIMARY KEY (`cmt_id`),
  KEY `tut_id` (`tut_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`cmt_id`, `name`, `email`, `message`, `ip`, `tut_id`) VALUES
(1, 'Samar', 'samar@techgaun.com', 'Good tutorial for beginners.', '127.0.0.1', 1);

-- --------------------------------------------------------

--
-- Table structure for table `config`
--

CREATE TABLE IF NOT EXISTS `config` (
  `config_name` varchar(100) NOT NULL,
  `config_value` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `config`
--


-- --------------------------------------------------------

--
-- Table structure for table `downloads`
--

CREATE TABLE IF NOT EXISTS `downloads` (
  `download_id` int(11) NOT NULL AUTO_INCREMENT,
  `download_title` varchar(100) NOT NULL,
  `download_desc` text,
  `download_path` varchar(255) NOT NULL,
  `uploaded_by` varchar(60) NOT NULL,
  PRIMARY KEY (`download_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `downloads`
--


-- --------------------------------------------------------

--
-- Table structure for table `forums`
--

CREATE TABLE IF NOT EXISTS `forums` (
  `forum_id` int(11) NOT NULL AUTO_INCREMENT,
  `forum_name` varchar(100) NOT NULL,
  `forum_desc` text NOT NULL,
  `redirect_url` varchar(120) DEFAULT NULL,
  `moderators` text,
  `num_topics` int(11) NOT NULL DEFAULT '0',
  `num_posts` int(11) NOT NULL DEFAULT '0',
  `last_post` int(11) NOT NULL DEFAULT '0',
  `last_post_id` int(11) NOT NULL,
  `last_poster` varchar(60) NOT NULL,
  `disp_position` int(11) NOT NULL DEFAULT '0',
  `cat_id` int(11) NOT NULL,
  PRIMARY KEY (`forum_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `forums`
--


-- --------------------------------------------------------

--
-- Table structure for table `forum_permission`
--

CREATE TABLE IF NOT EXISTS `forum_permission` (
  `group_id` int(11) NOT NULL,
  `forum_id` int(11) NOT NULL,
  `view_forum` tinyint(1) NOT NULL DEFAULT '1',
  `post_topics` tinyint(1) NOT NULL DEFAULT '1',
  `post_replies` tinyint(1) NOT NULL DEFAULT '1',
  KEY `group_id` (`group_id`,`forum_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `forum_permission`
--


-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_title` varchar(40) NOT NULL,
  `group_permission` tinyint(4) NOT NULL DEFAULT '3',
  PRIMARY KEY (`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`group_id`, `group_title`, `group_permission`) VALUES
(1, 'Member', 3),
(2, 'Administrator', 1),
(3, 'Moderator', 2);

-- --------------------------------------------------------

--
-- Table structure for table `links`
--

CREATE TABLE IF NOT EXISTS `links` (
  `link_id` int(11) NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL,
  `link_title` varchar(60) NOT NULL,
  `link_desc` varchar(255) NOT NULL DEFAULT 'Useful website for students',
  PRIMARY KEY (`link_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `links`
--

INSERT INTO `links` (`link_id`, `link_url`, `link_title`, `link_desc`) VALUES
(1, 'http://www.techgaun.com', 'Technology and more stuffs', 'Useful website for students'),
(2, 'http://www.nepali.netau.net', 'Hacking Challenges', 'Useful website for students');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `news_id` int(11) NOT NULL,
  `news_title` varchar(255) NOT NULL,
  `news_body` text NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`news_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `news`
--


-- --------------------------------------------------------

--
-- Table structure for table `online`
--

CREATE TABLE IF NOT EXISTS `online` (
  `user_id` int(11) NOT NULL,
  `ip` varchar(120) NOT NULL,
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `online`
--


-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE IF NOT EXISTS `permissions` (
  `group_id` int(11) NOT NULL,
  `forum_id` int(11) NOT NULL,
  `post_reply` tinyint(1) NOT NULL,
  `post_topics` tinyint(1) NOT NULL,
  `view_forum` tinyint(1) NOT NULL,
  KEY `group_id` (`group_id`,`forum_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `permissions`
--


-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `poster` varchar(40) NOT NULL,
  `poster_id` int(11) NOT NULL,
  `poster_ip` varchar(40) NOT NULL,
  `message` text NOT NULL,
  `posted` int(11) NOT NULL,
  `edited` int(11) DEFAULT NULL,
  `edited_by` varchar(40) DEFAULT NULL,
  `topic_id` int(11) NOT NULL,
  PRIMARY KEY (`post_id`),
  KEY `topic_id` (`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `posts`
--


-- --------------------------------------------------------

--
-- Table structure for table `ranks`
--

CREATE TABLE IF NOT EXISTS `ranks` (
  `rank_id` int(11) NOT NULL AUTO_INCREMENT,
  `rank_title` varchar(60) NOT NULL,
  `rank_posts` int(11) NOT NULL,
  PRIMARY KEY (`rank_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `ranks`
--


-- --------------------------------------------------------

--
-- Table structure for table `topics`
--

CREATE TABLE IF NOT EXISTS `topics` (
  `topic_id` int(11) NOT NULL AUTO_INCREMENT,
  `topic_creator` varchar(60) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `first_post_id` int(11) NOT NULL,
  `last_post` text NOT NULL,
  `last_post_id` int(11) NOT NULL,
  `last_poster` varchar(60) NOT NULL,
  `num_views` int(11) NOT NULL DEFAULT '1',
  `num_replies` int(11) NOT NULL DEFAULT '0',
  `closed` tinyint(1) NOT NULL DEFAULT '0',
  `sticky` tinyint(1) NOT NULL DEFAULT '0',
  `forum_id` int(11) NOT NULL,
  PRIMARY KEY (`topic_id`),
  KEY `forum_id` (`forum_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `topics`
--


-- --------------------------------------------------------

--
-- Table structure for table `topic_subscriptions`
--

CREATE TABLE IF NOT EXISTS `topic_subscriptions` (
  `user_id` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL,
  KEY `user_id` (`user_id`,`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `topic_subscriptions`
--


-- --------------------------------------------------------

--
-- Table structure for table `tutorial`
--

CREATE TABLE IF NOT EXISTS `tutorial` (
  `tut_id` int(11) NOT NULL AUTO_INCREMENT,
  `tut_title` varchar(100) NOT NULL,
  `tut_desc` varchar(255) NOT NULL DEFAULT 'Useful tutorial for students',
  `tut_body` text,
  `tut_rating` float DEFAULT NULL,
  `uploaded_by` varchar(60) NOT NULL,
  PRIMARY KEY (`tut_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tutorial`
--

INSERT INTO `tutorial` (`tut_id`, `tut_title`, `tut_desc`, `tut_body`, `tut_rating`, `uploaded_by`) VALUES
(1, 'Hacking for Beginners', 'Hacking for beginners is an absolutely great tutorial for everyone', 'Lets start hacking thing today. I am here to demonstrate you the art of hacking and cracking the web servers. :)', 4, 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(60) NOT NULL,
  `user_password` varchar(32) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `user_phone` varchar(20) DEFAULT NULL,
  `user_msn` varchar(100) DEFAULT NULL,
  `user_gtalk` varchar(100) DEFAULT NULL,
  `user_yahoo` varchar(100) DEFAULT NULL,
  `user_country` varchar(100) NOT NULL,
  `sig` varchar(250) DEFAULT '0',
  `style` varchar(40) NOT NULL DEFAULT 'default',
  `num_posts` int(11) NOT NULL DEFAULT '0',
  `last_visit` datetime NOT NULL,
  `activate_string` varchar(100) NOT NULL,
  `is_confirmed` tinyint(1) NOT NULL DEFAULT '0',
  `group_id` int(11) NOT NULL DEFAULT '3',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_name` (`user_name`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `users`
--


--
-- Constraints for dumped tables
--

--
-- Constraints for table `comment`
--
ALTER TABLE `comment`
  ADD CONSTRAINT `comment_ibfk_1` FOREIGN KEY (`tut_id`) REFERENCES `tutorial` (`tut_id`) ON DELETE CASCADE ON UPDATE CASCADE;

